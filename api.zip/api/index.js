const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const { Ollama } = require('ollama');

// Initialize Express and middleware
const app = express();
app.use(bodyParser.json());

// Initialize Ollama and variables
const ollama = new Ollama();
let conversationStarted = false;
let chatHistory = [];
const PORT = 3000;

// Web3 Expert System Prompt
const systemPrompt = "You are a Web3 expert. Answer all questions related to Web3 technologies, smart contracts, blockchain, and decentralized applications in a consise on the point manner.";

// Route to start the conversation
app.post('/start', (req, res) => {
  conversationStarted = true;
  chatHistory = [{ role: 'system', content: systemPrompt }];
  res.json({ message: 'Conversation started.' });
});

// Route for chatting
app.post('/chat', async (req, res) => {
  if (!conversationStarted) {
    return res.status(400).json({ error: 'Start the conversation first by hitting the /start endpoint.' });
  }

  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required.' });
  }

  try {
    // Add user message to chat history
    chatHistory.push({ role: 'user', content: message });

    // Get response from the Ollama chat model
    const response = await ollama.chat({
      model: 'llama3.2:1b',
      messages: chatHistory,
    });

    // Add Ollama's response to chat history
    const botResponse = response.message.content;
    chatHistory.push({ role: 'assistant', content: botResponse });

    res.json({ response: botResponse });
  } catch (error) {
    console.error('Error during chat:', error);
    res.status(500).json({ error: 'Something went wrong.' });
  }
});

// Route to stop the conversation and save history
app.post('/stop', (req, res) => {
  if (!conversationStarted) {
    return res.status(400).json({ error: 'Conversation is not started yet.' });
  }

  try {
    // Save chat history to a JSON file
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `chat-history-${timestamp}.json`;
    fs.writeFileSync(fileName, JSON.stringify(chatHistory, null, 2));

    conversationStarted = false;
    res.json({ message: 'Conversation stopped and saved.', file: fileName });
  } catch (error) {
    console.error('Error saving chat history:', error);
    res.status(500).json({ error: 'Failed to save chat history.' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
